package com.example.mycalculator1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    String input = "", result = "";
    char operation = 0;
//    double inputNo = 0, resultNo = 0;
    double inputData = 0, resultData = 0;
    TextView inputText;
    TextView resultText;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void displayResult(){
        resultText = findViewById(R.id.cummulative);
        resultText.setText(result);
    }

    public void displayInput(){
        inputText = findViewById(R.id.current);
        inputText.setText(String.valueOf(operation) + input);
    }

    public void setInput(String input) {
        inputText = findViewById(R.id.current);
        this.input = input;
    }

    public void setResult(String result) {
        resultText = findViewById(R.id.cummulative);
        this.result = result;
    }

    public void concatInput(String input) {
        inputText = findViewById(R.id.current);
        this.input += input;
    }

    public void truncatInput() {
        inputText = findViewById(R.id.current);

        if(input.length() != 0){
            input = input.substring(0, (input.length() - 1));
        }
        else if(operation != 0){
            operation = 0;
        }
    }

    public void setOperation(char operation) {
        this.operation = operation;
    }

    public void stringToDouble(){
        if(input.length() > 0) {
            inputData = Double.valueOf(input);
        }

        if(result.length() > 0) {
            resultData = Double.valueOf(result);
        }
    }

    public void doubleToString(){
        if(inputData != 0) {
            result = String.valueOf(resultData);
        }
    }

    protected void calculate(){
        stringToDouble();

        switch (operation){
            case 'X':
                resultData *= inputData;
                break;
            case '+':
                resultData += inputData;
                break;
            case '-':
                resultData -= inputData;
                break;
            case '/':
                resultData /= inputData;
                break;
            case '%':
                resultData = resultData * (inputData/100);
                break;
            default:
                resultData = inputData;
        }

        doubleToString();
        setInput("");

        inputData = 0;
        resultData = 0;
    }

    public void concatZero(View view){
        concatInput("0");
        displayInput();
    }

    public void concatOne(View view){
        concatInput("1");
        displayInput();
    }

    public void concatTwo(View view){
        concatInput("2");
        displayInput();
    }

    public void concatThree(View view){
        concatInput("3");
        displayInput();
    }

    public void concatFour(View view){
        concatInput("4");
        displayInput();
    }

    public void concatFive(View view){
        concatInput("5");
        displayInput();
    }

    public void concatSix(View view){
        concatInput("6");
        displayInput();
    }

    public void concatSeven(View view){
        concatInput("7");
        displayInput();
    }

    public void concatEight(View view){
        concatInput("8");
        displayInput();
    }

    public void concatNine(View view){
        concatInput("9");
        displayInput();
    }

    public void concatDecimal(View view){
        concatInput(".");
        displayInput();
    }

    public void clearAll(View view){
        operation = 0;
        setInput("");
        setResult("");
        displayInput();
        displayResult();
    }

    public void clearLast(View view){
        truncatInput();
        displayInput();
    }

    public void getProduct(View view){
        calculate();
        setOperation('X');
        displayInput();
        displayResult();
    }

    public void getSum(View view){
        calculate();
        setOperation('+');
        displayInput();
        displayResult();
    }

    public void getDifference(View view){
        calculate();
        setOperation('-');
        displayInput();
        displayResult();
    }

    public void getQuotient(View view){
        calculate();
        setOperation('/');
        displayInput();
        displayResult();
    }

    public void getPercentage(View view){
        calculate();
        setOperation('%');
        displayInput();
        displayResult();
    }

    public void getResult(View view){
        calculate();
        setOperation('\0');
        displayInput();
        displayResult();
    }
}